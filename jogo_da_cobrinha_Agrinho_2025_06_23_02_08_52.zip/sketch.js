let scale = 20;

let cols, rows;

let snake;

let food;

let direction = 'RIGHT';

let touchStartX, touchStartY;

let gameStarted = false;

function setup() {

  createCanvas(windowWidth, windowHeight);

  frameRate(10);

  cols = floor(width / scale);

  rows = floor(height / scale);

  snake = new Snake();

  food = createFood();

  textAlign(CENTER, CENTER);

  textSize(24);

}

function draw() {

  background(220, 255, 220);

  if (!gameStarted) {

    // tela de início

    fill(0);

    textSize(32);

    text("🚜 Trator Snake 🚜", width / 2, height / 2 - 40);

    textSize(20);

    text("Toque ou clique para começar", width / 2, height / 2 + 10);

    return;

  }

  scale(scale);

  snake.update();

  snake.show();

  if (snake.eat(food)) {

    food = createFood();

  }

  drawFood(food.x, food.y);

}

function mousePressed() {

  if (!gameStarted) gameStarted = true;

}

function touchStarted() {

  if (!gameStarted) {

    gameStarted = true;

  } else {

    touchStartX = mouseX;

    touchStartY = mouseY;

  }

}

function touchEnded() {

  if (!gameStarted) return;

  let dx = mouseX - touchStartX;

  let dy = mouseY - touchStartY;

  if (abs(dx) > abs(dy)) {

    if (dx > 0 && direction !== 'LEFT') direction = 'RIGHT';

    else if (dx < 0 && direction !== 'RIGHT') direction = 'LEFT';

  } else {

    if (dy > 0 && direction !== 'UP') direction = 'DOWN';

    else if (dy < 0 && direction !== 'DOWN') direction = 'UP';

  }

}

function keyPressed() {

  if (!gameStarted) return;

  if (keyCode === UP_ARROW && direction !== 'DOWN') direction = 'UP';

  else if (keyCode === DOWN_ARROW && direction !== 'UP') direction = 'DOWN';

  else if (keyCode === LEFT_ARROW && direction !== 'RIGHT') direction = 'LEFT';

  else if (keyCode === RIGHT_ARROW && direction !== 'LEFT') direction = 'RIGHT';

}

class Snake {

  constructor() {

    this.body = [createVector(5, 5)];

    this.len = 1;

  }

  update() {

    let head = this.body[this.body.length - 1].copy();

    if (direction === 'UP') head.y--;

    else if (direction === 'DOWN') head.y++;

    else if (direction === 'LEFT') head.x--;

    else if (direction === 'RIGHT') head.x++;

    this.body.push(head);

    if (this.body.length > this.len) {

      this.body.shift();

    }

    if (this.checkCollision()) {

      this.body = [createVector(5, 5)];

      this.len = 1;

      direction = 'RIGHT';

      gameStarted = false; // reinicia para a tela de início

    }

  }

  show() {

    for (let i = 1; i < this.body.length; i++) {

      drawFardo(this.body[i].x, this.body[i].y);

    }

    drawTrator(this.body[this.body.length - 1].x, this.body[this.body.length - 1].y);

  }

  eat(pos) {

    let head = this.body[this.body.length - 1];

    return head.x === pos.x && head.y === pos.y && ++this.len;

  }

  checkCollision() {

    let head = this.body[this.body.length - 1];

    for (let i = 0; i < this.body.length - 1; i++) {

      if (this.body[i].x === head.x && this.body[i].y === head.y) return true;

    }

    return head.x < 0 || head.y < 0 || head.x >= cols || head.y >= rows;

  }

}

function drawTrator(x, y) {

  push();

  translate(x, y);

  fill(50, 50, 200);

  rect(0.1, 0.1, 0.8, 0.8, 0.2);

  fill(30);

  ellipse(0.2, 0.9, 0.2, 0.2);

  ellipse(0.7, 0.9, 0.2, 0.2);

  pop();

}

function drawFardo(x, y) {

  push();

  translate(x, y);

  fill(255, 215, 0);

  rect(0, 0, 1, 1, 0.2);

  stroke(200, 150, 0);

  line(0.2, 0.2, 0.8, 0.2);

  line(0.2, 0.5, 0.8, 0.5);

  line(0.2, 0.8, 0.8, 0.8);

  pop();

}

function drawFood(x, y) {

  push();

  translate(x, y);

  fill(255, 100, 100);

  ellipse(0.5, 0.5, 0.6, 0.6);

  pop();

}